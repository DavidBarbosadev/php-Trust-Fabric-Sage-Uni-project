<?php
include "app/master.php";
include "app/controller/documentcontroller.php";
include "app/controller/administratorcontroller.php";
include "app/model/organizationmodel.php";
session_start();
$adminRole = false;
function generateRandomString($length = 35) {
    return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);
}
if (isset($_SESSION['id'])){
    $administratorCtrl = new AdministratorController($_SESSION['id']);
    if ($administratorCtrl->checkSession() == 1){
        $adminRole = true;
    }
}
if (isset($_GET['hashkey'])){
    $documentCtrl = new DocumentController($_GET['hashkey']);
    $document = $documentCtrl->view();
    if (empty($document)){
        echo "<script>alert('Invalid hashkey');window.history.go(-1);</script>";
    }
    $hashkey = $document->hashkey == null ? "" : $document->hashkey;
    $dtCreated = $document->dtcreated == null ? "" : $document->dtcreated;
    $dtPayment = $document->dtpaid == null ? "" : $document->dtpaid;
    $amtPayment = $document->amountPaid == null ? "" : $document->amountPaid;
    $referenceNo = $document->referenceNumber == null ? "" : $document->referenceNumber;
    $note = $document->note == null ? "" : $document->note;
    $vatNumber = $document->vatNumber == null ? "" : $document->vatNumber;
    $dtdue = $document->dtdue == null ? "" : $document->dtdue;
    $dtlastmodified = $document->dtlastmodified == null ? "" : $document->dtlastmodified;
    $creator = $document->createdBy == null ? "" : $document->createdBy;
    $organization = $document->belongedToOrganization == null ? "" : $document->belongedToOrganization;
    $owner = $document->paidBy == null ? "" : $document->paidBy;
    $administratorCtrl = new AdministratorController($creator);
    $administratorInfo = $administratorCtrl->viewProfile();
    $creator = $administratorInfo->firstname." ".$administratorInfo->lastname;
}
if (isset($_POST['action'])){
    switch($_POST['action']){
        case "modifyDocument":
            $saved = false;
            if (empty($_POST['hashkey'])){
                echo "<script>alert('Please fill in hashkey in the textbox');window.history.go(-1);</script>";
                exit();
            }
            if (empty($_POST['organization'])){
                echo "<script>alert('Please select in organization in the select box');window.history.go(-1);</script>";
                exit();
            }
            if (empty($_POST['vatNumber'])){
                echo "<script>alert('Please fill in VAT Number in the textbox');window.history.go(-1);</script>";
                exit();
            }
            if (empty($_POST['amountdue'])){
                echo "<script>alert('Please fill in amount due in the textbox');window.history.go(-1);</script>";
                exit();
            }
            if (empty($_POST['duedte'])){
                echo "<script>alert('Please fill in due date in the textbox');window.history.go(-1);</script>";
                exit();
            }
            if (empty($_POST['owner'])){
                echo "<script>alert('Please fill in owner name in the textbox');window.history.go(-1);</script>";
                exit();
            }
            $documentCtrl = new DocumentController($_POST['hashkey'],$_POST['organization'],$_POST['vatNumber'],$_POST['amountdue'],$_POST['duedte'],$_POST['note'],$_POST['owner']);
            if ($documentCtrl->update() == true){
                $saved = true;
            }
            if (isset($_POST['payment_status']) && $_POST['payment_status'] == "Yes"){
                $documentCtrl = new DocumentController($_POST['hashkey'],$_POST['paymentdte'],$_POST['referenceNumber']);
                if ($documentCtrl->updatePayment()){
                    $saved = true;
                }
            }
            if ($saved == true){
                echo "<script>alert('The changes has been saved');window.location.href='payment.php?hashkey={$_POST['hashkey']}';</script>";
                exit();
            }
            else{
                echo "<script>alert('The changes has not been saved');window.history.go(-1);</script>";
                exit();
            }
        break;
        case "newDocument":
            if (empty($_POST['hashkey'])){
                echo "<script>alert('Please fill in hashkey in the textbox');window.history.go(-1);</script>";
                exit();
            }
            if (empty($_POST['organization'])){
                echo "<script>alert('Please select in organization in the select box');window.history.go(-1);</script>";
                exit();
            }
            if (empty($_POST['vatNumber'])){
                echo "<script>alert('Please fill in VAT Number in the textbox');window.history.go(-1);</script>";
                exit();
            }
            if (empty($_POST['amountdue'])){
                echo "<script>alert('Please fill in amount due in the textbox');window.history.go(-1);</script>";
                exit();
            }
            if (empty($_POST['duedte'])){
                echo "<script>alert('Please fill in due date in the textbox');window.history.go(-1);</script>";
                exit();
            }
            if (empty($_POST['owner'])){
                echo "<script>alert('Please fill in owner name in the textbox');window.history.go(-1);</script>";
                exit();
            }
            $documentCtrl = new DocumentController($_POST['hashkey'],$_POST['organization'],$_POST['vatNumber'],$_POST['amountdue'],$_POST['duedte'],$_POST['note'],$_POST['paymentdte'],$_POST['referenceNumber'],$_POST['owner'],$_SESSION['id']);
            if ($documentCtrl->create()){
                echo "<script>alert('The document is created successfully');window.location.href='viewrecord.php';</script>";
                exit();
            }
            else{
                echo "<script>alert('The document was not created successfully');window.history.go(-1);</script>";
                exit(); 
            }
        break;
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="css/userupdate.css?v=2">
    <link rel="stylesheet" href="css/indexstyle.css">
    <script src="https://code.jquery.com/jquery-2.2.4.js" integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI=" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script type="text/javascript">
        function toggle() {
            var header = document.getElementById("header")
            header
                .classList
                .toggle('active')
        }

        function showhide(x) {
            if (x == 0)
                document
                .getElementById('showhide')
                .style
                .display = 'block';
            else
                document
                .getElementById('showhide')
                .style
                .display = 'none';
            return;
        }
    </script>

    <title>Partilha -Create New Record</title>
</head>

<body>
    <header id="header">
        <?php include "commonHeader.php"; ?>
    </header>
    <br />
    <section>
        <div class="container">
            <div class="row justify-content-center">
                <h1>Record</h1>
            </div>
            <div class="row justify-content-center">
                <h5>Document Details</h5>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <form method="POST">
                        <input type="hidden" name="action" value="<?php echo (isset($_GET['hashkey']) ? "modifyDocument" : "newDocument"); ?>">
                        <?php echo (isset($_GET['hashkey']) ? "<input type=\"hidden\" name=\"hashkey\" value=\"{$hashkey}\">" : ""); ?>
                        <div class=" invisible form-group row">
                            <label for="inputEmail3" class="text col-sm-4 col-form-label">Hashkey</label>
                            <div class="col-sm-8">
                                <input id="hash" autocomplete="off" type="text" readonly contenteditable="false" value="<?php echo (isset($_GET['hashkey']) ? $hashkey : generateRandomString()); ?>" class="form-control" name="hashkey">
                            </div>
                        </div>

                       

                        <div class="form-group row">
                            <label for="sltOrg" class=" text col-sm-4 col-form-label">Organization
                            </label>
                            <div class="col-sm-8">
                                <?php
                                if (isset($_GET['hashkey']) && $adminRole == false) {
                                    echo '<input autocomplete="off" style="margin-left:10px;" type="text" value="' . OrganizationModel::view($organization) . '" readonly class="form-control" id="inputEmail3">';
                                } else {
                                    echo "<select class=\"form-control\" name=\"organization\" style=\"margin-left:10px;\">";
                                    $orgs = json_decode(OrganizationModel::getAll());
                                    foreach ($orgs as $org) {
                                        echo "<option" . ($organization == $org->id ? " selected " : " ") . "value=\"{$org->id}\">{$org->organization}</option>";
                                    }
                                    echo  "</select>";
                                }
                                ?>
                            </div>
                        </div>
                        <div class=" form-group row">
                            <label for="inputEmail3" class="text col-sm-4 col-form-label">VAT Number</label>
                            <div class="col-sm-8">
                                <input id="vat" value="<?php echo (isset($_GET['hashkey']) ? $vatNumber : ""); ?>" <?php echo $adminRole == false ? (isset($_GET['hashkey']) ? "readonly" : "") : ""; ?> type="text"  name="vatNumber" autocomplete="off" class="form-control">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class=" text col-sm-4 col-form-label">Paid by</label>
                            <div class="col-sm-8">
                                <input value="<?php echo (isset($_GET['hashkey']) ? $owner : ""); ?>" <?php echo $adminRole == false ? (isset($_GET['hashkey']) ? "readonly" : "") : ""; ?> type="text" autocomplete="off" name="owner" class="form-control" id="paidby">
                            </div>
                        </div>
                        <?php
                        if (isset($_GET['hashkey'])) {
                        ?>
                            <div class="form-group row">
                                <label for="inputEmail3" class="text col-sm-4 col-form-label">Creator</label>
                                <div class="col-sm-8">
                                    <input value="<?php echo $creator; ?>" readonly="readonly" type="text" autocomplete="off" name="dtmodifiedtime" class="form-control" id="creator">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="inputEmail3" class="text col-sm-4 col-form-label">Last modified date and time</label>
                                <div class="col-sm-8">
                                    <input value="<?php echo $dtlastmodified; ?>" readonly="readonly" type="text" autocomplete="off" name="dtmodifiedtime" class="form-control" id="lastmodified">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="inputEmail3" class="text col-sm-4 col-form-label">Document creation date and time</label>
                                <div class="col-sm-8">
                                    <input value="<?php echo $dtCreated; ?>" readonly="readonly" type="text" autocomplete="off" name="dtcreated" class="form-control" id="documentcreation">
                                </div>
                            </div>
                        <?php
                        }
                        ?>
                        <div class="form-group row div-paid-dte">
                            <label for="inputEmail3" class="text col-sm-4 col-form-label">Paid date and time</label>
                            <div class="col-sm-8">
                                <input value="<?php echo isset($_GET['hashkey']) ? $dtPayment : ""; ?>" <?php echo $adminRole == false ? "readonly" : ""; ?> type="<?php echo (($adminRole == true) ? "date" : "text"); ?>" name="paymentdte" class="form-control" id="paiddate">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="text col-sm-4 col-form-label">Due date and time</label>
                            <div class="col-sm-8">
                                <input id="duedate" value="<?php echo isset($_GET['hashkey']) ? $dtdue : ""; ?>" <?php echo $adminRole == false ? "readonly" : ""; ?> type="<?php echo (($adminRole == true) ? "date" : "text"); ?>" autocomplete="off" name="duedte" class="form-control">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="text col-sm-4 col-form-label">Amount due</label>
                            <div class="col-sm-8">
                                <input value="<?php echo isset($_GET['hashkey']) ? $amtPayment : ""; ?>" <?php echo $adminRole == false ? "readonly" : ""; ?> type="text" autocomplete="off" name="amountdue" class="form-control" id="amountdue">
                            </div>
                        </div>

                        <div class="form-group row div-reference-no">
                            <label for="inputEmail3" class="text col-sm-4 col-form-label">Reference Number</label>
                            <div class="col-sm-8">
                                <input value="<?php echo isset($_GET['hashkey']) ? $referenceNo : ""; ?>" <?php echo $adminRole == false ? "readonly" : ""; ?> type="text" autocomplete="off" name="referenceNumber" class="form-control" id="Referencenumber">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="inputEmail3" class="text col-sm-4 col-form-label">Payment Status</label>
                            <div class="col-sm-8">
                                <label class="radio-inline">
                                    <input type="radio" id="yes" <?php echo $adminRole == false ? "disabled " : ""; ?> <?php echo (isset($_GET['hashkey']) ? (empty($dtPayment) ? "" : "checked ") : ""); ?>value="Yes" name="payment_status">Paid
                                </label>
                                <label class="radio-inline">
                                    <input type="radio" id="no" <?php echo $adminRole == false ? "disabled " : ""; ?> <?php echo (isset($_GET['hashkey']) ? (!empty($dtPayment) ? "" : "checked ") : ""); ?>value="No" name="payment_status" id="no">Unpaid
                                </label>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="inputEmail3" class="text col-sm-4 col-form-label">Note</label>
                            <div class="col-sm-8">
                                <textarea rows="4" <?php echo $adminRole == false ? " disabled" : ""; ?> name="note" id="note" style="margin-left:10px;" class="form-control"><?php echo isset($_GET['hashkey']) ? $note : ""; ?>
                                    </textarea>
                            </div>
                        </div>

                        <?php
                        if ($adminRole == true) {
                        ?>
                            <div class="form-group row">
                                <div class="col-sm-12">
                                    <button onclick="createPDF()" type="submit" class="float-right btn btn-light">Save Changes</button>
                                </div>
                            </div>
                        <?php
                        }
                        ?>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <script type="text/javascript">
        $(".radio-inline")
            .unbind("click")
            .click(function() {
                console.log($(this).children("input").val());
                switch ($(this).children("input").val()) {
                    case "Yes":
                        $(".div-paid-dte").css("display", "").attr("type", "date");
                        $(".div-reference-no").css("display", "");
                        break;
                    case "No":
                        $(".div-paid-dte").css("display", "none").attr("type", "text");
                        $(".div-reference-no").css("display", "none");
                        break;
                }
            });
    </script>
</body>

</html>
<?php
session_start();
include "app/master.php";
include "app/controller/administratorcontroller.php";
if (!isset($_SESSION['id'])){
    echo "<script>alert('Please do login first');window.location.href='adminlogin.php'</script>";
    exit();
}
$administratorCtrl = new AdministratorController($_SESSION['id']);
if (!($administratorCtrl->checkSession() == 1)){
    echo "<script>alert('Please do login first2');window.location.href='adminlogin.php'</script>";
    exit();   
}
$rGetInfo = $administratorCtrl->viewProfile();
if (isset($_POST['action']) && $_POST['action'] == "updateProfile"){
    $chgpwd = true;
    if (empty($_POST['opass']) || empty($_POST['pass']) || empty($_POST['cfmpass'])){
        $chgpwd = false;
    }
    switch($chgpwd){
        case true:
            $administratorCtrl = new AdministratorController($_SESSION['id']);
            if ($administratorCtrl->doChangePassword($_POST['opass'],$_POST['pass'])){
                echo "<script>alert('Successfully change password and update profile');window.location.href='profile.php';</script>";
                exit();
            }
            else{
                echo "<script>alert('Old password is incorrect');window.location.href='profile.php';</script>";
                exit();
            }
        break;
        case false:
            if (empty($_POST['firstname'])){
                echo "<script>alert('Please fill in first name in the textbox');window.history.go(-1);</script>";
                exit();
            }
            if (empty($_POST['lastname'])){
                echo "<script>alert('Please fill in last name in the textbox');window.history.go(-1);</script>";
                exit();
            }
            $administratorCtrl = new AdministratorController($_SESSION['id']);
            if ($administratorCtrl->updateProfile($_POST['firstname'],$_POST['lastname'])){
                echo "<script>alert('Successfully update profile');window.location.href='profile.php';</script>";
                exit();
            }
            else{
                echo "<script>alert('We have detected nothing changes');window.location.href='profile.php';</script>";
                exit();
            }
        break;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <link rel="stylesheet" href="css/indexstyle.css">
        <meta charset="UTF-8">
        <link
            rel="stylesheet"
            href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
            integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
            crossorigin="anonymous">
        <link rel="stylesheet" href="css/userupdate.css?v=1">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Partilha -File's information Page</title>
        <script type="text/javascript">
            function toggle() {
                var header = document.getElementById("header")
                header
                    .classList
                    .toggle('active')
            }
        </script>
    </head>

    <body>
    <header id="header">
            <?php include "commonHeader.php"; ?>
            
        </header>
        <br>
        <section>
            <div class="container">
                <div class="row justify-content-center">
                    <h1>Manage Profile</h1>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <form method="POST">
                            <input type="hidden" name="action" value="updateProfile">
                            <div class="form-group row">
                                <label for="inputEmail3" class="text col-sm-4 col-form-label">User ID</label>
                                <div class="col-sm-8">
                                    <input type="email" disabled value="<?php echo isset($rGetInfo->id) ? $rGetInfo->id : ""; ?>" class="form-control" id="inputEmail3">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="inputEmail3" class="text col-sm-4 col-form-label">Email address</label>
                                <div class="col-sm-8">
                                    <input type="email" disabled name="email" value="<?php echo isset($rGetInfo->email) ? $rGetInfo->email : ""; ?>" class="form-control" id="inputEmail3">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="inputEmail3" class="text col-sm-4 col-form-label">First name</label>
                                <div class="col-sm-8">
                                    <input type="text" name="firstname" value="<?php echo isset($rGetInfo->firstname) ? $rGetInfo->firstname : ""; ?>" class="form-control" id="inputEmail3">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="inputPassword3" class="text col-sm-4 col-form-label">Last name</label>
                                <div class="col-sm-8">
                                    <input type="text" name="lastname" value="<?php echo isset($rGetInfo->lastname) ? $rGetInfo->lastname : ""; ?>" class="form-control" id="inputPassword3">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="inputPassword3" class="text col-sm-4 col-form-label">Old Password</label>
                                <div class="col-sm-8">
                                    <input type="password" name="opass" class="form-control" id="inputPassword3">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="inputPassword3" class="text col-sm-4 col-form-label">New Password</label>
                                <div class="col-sm-8">
                                    <input type="password" name="pass" class="form-control" id="inputPassword3">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="inputPassword3" class="text col-sm-4 col-form-label">Confirm New Password</label>
                                <div class="col-sm-8">
                                    <input type="password" name="cfmpass" class="form-control" id="inputPassword3">
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-sm-12">
                                    <button type="submit" class="float-right btn btn-primary btn-lg">Save Changes</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
</body>
</html>
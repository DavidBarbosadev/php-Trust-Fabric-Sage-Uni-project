<a href="loginlanding.php" class="logo"><img src="img/logo/Partilha Logo.png" alt="logo"></a>
            <ul>
               <li>
                    <a href="profile.php">Profile</a>
                </li>
                <li>
                    <a href="viewrecord.php">View Record</a>
                </li>
                <li>
                    <a href="payment.php">New Record</a>
                </li>
                <li>
                    <a href="logout.php" onclick="toggle()">Log out</a>
                </li>
                <li>
                    <a href="#"><img src="img/png/profile.png" alt=""></a>
                </li>
                </ul>
            <div class="toggle" onclick="toggle()"></div>
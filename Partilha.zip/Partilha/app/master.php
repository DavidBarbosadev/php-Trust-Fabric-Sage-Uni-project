<?php
include $_SERVER['DOCUMENT_ROOT']."/app/model/database.php";
include $_SERVER['DOCUMENT_ROOT']."/app/util.php";
?>
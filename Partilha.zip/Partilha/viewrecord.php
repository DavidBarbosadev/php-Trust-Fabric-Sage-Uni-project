<?php
session_start();
include "app/master.php";
include "app/controller/administratorcontroller.php";
include "app/controller/documentcontroller.php";
include "app/model/organizationmodel.php";
if (!isset($_SESSION['id'])){
    echo "<script>alert('no permission to access here');window.location.href='index.php';</script>";
    exit();
}
$administratorCtrl = new AdministratorController($_SESSION['id']);
if ($administratorCtrl->checkSession() != 1){
    echo "<script>alert('no permission to access here');window.location.href='index.php';</script>";
    exit();
}
if (isset($_GET['action']) && $_GET['action'] == "delete"){
    $documentCtrl = new DocumentController($_GET['hashkey']);
    if ($documentCtrl->delete()){
        echo "<script>alert('File has been successfully deleted from the system');window.location.href='viewrecord.php';</script>";
        exit();
    }
    else{
        echo "<script>alert('The file has been deleted previously.');window.location.href='viewrecord.php';</script>";
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <link
            rel="stylesheet"
            href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
            integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
            crossorigin="anonymous">
        <link
            rel="stylesheet"
            href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
            integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p"
            crossorigin="anonymous"/>
        <link rel="stylesheet" href="css/userupdate.css?v=1">
        <script
            src="https://code.jquery.com/jquery-2.2.4.js"
            integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
            crossorigin="anonymous"></script>
        <script
            src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/1.5.13/clipboard.min.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script type="text/javascript">
            function toggle() {
                var header = document.getElementById("header")
                header
                    .classList
                    .toggle('active')
            }

            function showhide(x) {
                if (x == 0) 
                    document
                        .getElementById('showhide')
                        .style
                        .display = 'block';
                else 
                    document
                        .getElementById('showhide')
                        .style
                        .display = 'none';
                return;
            }
        </script>
        <link rel="stylesheet" href="css/indexstyle.css">
        <title>Partilha -Create New Record</title>
        <style>
            h1{
                padding-top:30px;
            }
        </style>
    </head>
    <body>
        <header id="header">
            <?php include "commonHeader.php"; ?>
        </header>
        <br/>
        <section>

            



            <div class="container-fluid">
                <div class="row justify-content-center">
                    <h1>View Record</h1>
                </div>
                <div class="row justify-content-end">
                    <button
                        type="button"
                        style="display:inline-block;margin-right:15px;margin-bottom:5px;"
                        class="btn btn-info"
                        onclick="window.location.href='payment.php'">Create New Document</button>
                </div>
                <div class="row justify-content-center">
                    <input id="cb" style="display:none;" type="text">
                    <div class="col-lg-8 col-lg-12">
                        <table id="dt-select" class="table table-responsive w-100 d-block d-xl-table table-striped" cellspacing="0" width="100%">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">File Information</th>
                                    <th scope="col">Organization</th>
                                    <th scope="col">VAT Number</th>
                                    <th scope="col">Payment Status</th>
                                    <th scope="col">Date creation</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
  $documentCtrl = new DocumentController();
  $documents = json_decode($documentCtrl->viewAll());
  if (count($documents) > 0){
      $i = 1;
    foreach($documents as $document){
        $pytInfo = "Amount: GBP{$document->amountPaid}<br/>Status:Pending";
        if (!empty($document->paidBy)){
            $pytInfo = "Amount: GBP {$document->amountPaid}<br/>";
            $pytInfo .= "Payer by ".$document->paidBy."<br/>";
            $pytInfo .= "Paid at {$document->dtpaid}";
        }
        $administratorCtrl = new AdministratorController($document->createdBy);
        $administratorInfo = $administratorCtrl->viewProfile();
        $creator = $administratorInfo->firstname." ".$administratorInfo->lastname;
        echo "<tr>
        <th scope=\"row\">{$i}</th>
        <td>Hash(SHA1):{$document->hashkey}&nbsp;<i onclick=\"copy(this);\" data-id=\"{$document->hashkey}\" style=\"cursor:pointer;\" class=\"far fa-copy\"></i><br/>Created by:{$creator}</td>
        <td>".OrganizationModel::view($document->belongedToOrganization)."</td>
        <td>{$document->vatNumber}</td>
        <td>{$pytInfo}</td>
        <td>{$document->dtcreated}</td>
        <td><button type=\"button\" onclick=\"window.location='payment.php?hashkey={$document->hashkey}'\" class=\"btn btn-primary\"><i class=\"fas fa-edit\"></i></button>&nbsp;<button type=\"button\" onclick=\"window.location.href='viewrecord.php?action=delete&hashkey={$document->hashkey}'\" class=\"btn btn-danger\"><i class=\"fas fa-times\"></i></button></td>
      </tr>";
        $i++;
    }
  }
  else{
    echo "<tr><td colspan=\"6\">There's document found in the system yet!</td></tr>";
  }
  ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <script type="text/javascript">
        function copy(ths) {
            //ths = $(selector);
            $("#cb").css("display", "block");
            var copyText = document.getElementById("cb");
            copyText.value = $(ths).data("id");
            copyText.focus();
            copyText.select();
            document.execCommand('copy');
            $("#cb").css("display", "none");
        }
        function copyToClipboard(txt) {
            $("#cb").val(txt);
            copy($("#cb"));
        }
    </script>
</body>
</html>
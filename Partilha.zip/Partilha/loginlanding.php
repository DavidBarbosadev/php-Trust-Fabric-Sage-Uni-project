<?php
session_start();
include "app/master.php";
include "app/controller/administratorcontroller.php";
if (!isset($_SESSION['id'])){
    echo "<script>alert('no permission to access here');window.location.href='index.php';</script>";
    exit();
}
$administratorCtrl = new AdministratorController($_SESSION['id']);
if (!($administratorCtrl->checkSession() == 1)){
    echo "<script>alert('no permission to access here');window.location.href='index.php';</script>";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href="https://fonts.googleapis.com/css2?family=Permanent+Marker&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/dashboardstyle.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Partilha -Dashboard</title>
</head>
<body>
    <div class="sidebar" id="sidebar">
        <div class="toggle" onclick="toggle_div()" ></div>
            <ul>
            <!-- 1:admin, 2: normal user -->
                <li><a href="viewrecord.php">View Record</a></li>
                <li><a href="profile.php">Manage Profile</a></li>
                <li><a href="logout.php">Log Out</a></li>
                <li><a href="#"><img src="img/png/profile.png" alt=""></a></li>
            </ul>
        
    </div>
    <div class="h1">
        <h1>Welcome</h1>
    </div>


    <div class="box">
        <div class="text">
            <div>
                <h1>Instructions</h1>
                <p>Hello User, welcome to your dashboard. 
This dashboard is your main stage of this application. From here you can choose from many options in order to manage and organise your business.
From this dashboard you have the ability to access to many features of the application. Search for specific records, produce new records,
 update record’s information and much more starting just by clicking on the arrow on the left Side. </p>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        function toggle_div(){
            var element = document.getElementById('sidebar');
            element.classList.toggle('active')
        } 
    </script>
</body>
</html>
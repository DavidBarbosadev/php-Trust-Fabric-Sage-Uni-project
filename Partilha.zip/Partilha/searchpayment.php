<?php
include "app/master.php";
include "app/controller/documentcontroller.php";
if (isset($_POST['action']) && $_POST['action'] == "searchHash"){
    if (empty($_POST['hashkey'])){
        echo "<script>alert('Please fill in hash key in the textbox');window.history.go(-1);</script>";
        exit();
    }
    $documentCtrl = new DocumentController($_POST['hashkey']);
    if ($documentCtrl->search()){
        echo "<script>window.location.href='payment.php?hashkey={$_POST['hashkey']}';</script>";
        exit();
    }
    else{
        echo "<script>alert('Invalid hashkey');window.history.go(-1);</script>";
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <link
            rel="stylesheet"
            href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
            integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
            crossorigin="anonymous">
        <link rel="stylesheet" href="css/userupdate.css">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Partilha -Search Page</title>
        <script type="text/javascript">
            function toggle() {
                var header = document.getElementById("header")
                header
                    .classList
                    .toggle('active')
            }
        </script>
    </head>
    <body>
        <header id="header">
            <a href="index.php" class="logo"><img src="img/logo/Partilha Logo.png" alt="logo"></a>
            <ul>
                <li><a href="index.php" style="margin-right:10px;" onclick="toggle()">Home</a></li>
            </ul>
            <div class="toggle" onclick="toggle()"></div>
        </header>

        <section>
        <div class="container">
                <div style="margin-top:20px;" class="row justify-content-center">
                    <h1>Search Signature</h1>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <form method="POST" style="text-algin:left;">
                            <input type="hidden" name="action" value="searchHash">
                            <div class="form-group row">
                                <label for="inputEmail3" class="text col-sm-3 col-form-label">Hash Key</label>
                                <div class="col-sm-9">
                                    <input
                                        autocomplete="off"
                                        type="text"
                                        class="form-control"
                                        id="inputEmail3"
                                        name="hashkey">
                                </div>
                            </div>
                                   <center> <button type="submit" class="btn btn-primary btn-lg">Search</button></center>
                            </form>
                            </div>
                            </div>
                            </div>

        </body>
    </html>